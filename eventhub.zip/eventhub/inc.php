<?php
session_start();
date_default_timezone_set('Africa/Kigali');
// ---- Email (SMTP). Leave SMTP_USER empty to save emails as HTML files in /outbox instead (good for local testing).
const SMTP_HOST='smtp.gmail.com', SMTP_PORT=587, SMTP_USER='', SMTP_PASS='', MAIL_FROM_NAME='EventHub';
try{$pdo=new PDO('mysql:host=localhost;dbname=eventhub;charset=utf8mb4','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}
catch(Exception $x){die('Database not found. Import database.sql in phpMyAdmin first.');}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function me(){return $_SESSION['u']??null;}
function money($n){return $n>0?'RWF '.number_format($n):'Free';}
function flash($m=null,$t='ok'){if($m){$_SESSION['f']=[$m,$t];return;}$f=$_SESSION['f']??null;unset($_SESSION['f']);return $f;}
function need_login($r=''){if(!me()){header("Location:{$r}auth.php?next=".urlencode($_SERVER['REQUEST_URI']));exit;}}
function need_admin(){if(!me()||me()['role']!=='admin'){header('Location:../auth.php');exit;}}
const TLEFT="t.seats-(SELECT COUNT(DISTINCT k.unit_no) FROM tickets k JOIN orders o ON o.id=k.order_id WHERE k.type_id=t.id AND o.status='confirmed')";
function flyer($x,$r=''){return $x['flyer']?'<img src="'.$r.'uploads/'.e($x['flyer']).'" alt="Flyer for '.e($x['title']).'">':'<div class="noflyer"><span>'.e($x['category']).'</span><b>'.e($x['title']).'</b></div>';}
function qr_png($text,$size=6){ // pure PHP PNG writer: needs zlib only, no GD
 require_once __DIR__.'/lib/qrcode.php';$q=QRCode::getMinimumQRCode($text,QR_ERROR_CORRECT_LEVEL_M);$n=$q->getModuleCount();$m=4;$w=($n+2*$m)*$size;$raw='';
 for($r=-$m;$r<$n+$m;$r++){
  if($r<0||$r>=$n)$line=str_repeat("\xFF",$w);
  else{$line=str_repeat("\xFF",$m*$size);for($c=0;$c<$n;$c++)$line.=str_repeat($q->isDark($r,$c)?"\x00":"\xFF",$size);$line.=str_repeat("\xFF",$m*$size);}
  $raw.=str_repeat("\x00".$line,$size);}
 $ch=function($t,$d){return pack('N',strlen($d)).$t.$d.pack('N',crc32($t.$d));};
 return "\x89PNG\r\n\x1a\n".$ch('IHDR',pack('NNCCCCC',$w,$w,8,0,0,0,0)).$ch('IDAT',gzcompress($raw)).$ch('IEND','');}
function tickets_of($pdo,$where,$p){$s=$pdo->prepare("SELECT k.*,t.name tier,t.group_size,e.title,e.event_date,e.venue,e.city,o.status,o.total,o.pay_method,o.pay_detail,o.pay_ref,o.user_id,u.name buyer,u.email FROM tickets k JOIN orders o ON o.id=k.order_id JOIN ticket_types t ON t.id=k.type_id JOIN events e ON e.id=o.event_id JOIN users u ON u.id=o.user_id WHERE $where ORDER BY k.id");$s->execute($p);return $s->fetchAll();}
function seat_label($k){return $k['group_size']>1?'Table '.$k['unit_no'].' · Seat '.$k['guest_idx']:'Seat '.$k['unit_no'];}
function head($t,$r=''){$u=me();$f=flash();?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($t)?> · EventHub</title><link rel="stylesheet" href="<?=$r?>assets/style.css"></head><body>
<header class="nav"><a class="logo" href="<?=$r?>index.php">Event<b>Hub</b></a><nav>
<a href="<?=$r?>index.php">Events</a>
<?php if($u): ?><a href="<?=$r?>my_tickets.php">My tickets</a><a href="<?=$r?>account.php">Account</a>
<?php if($u['role']==='admin'): ?><a href="<?=$r?>admin/index.php">Admin</a><?php endif; ?>
<a href="<?=$r?>logout.php">Log out (<?=e(explode(' ',$u['name'])[0])?>)</a>
<?php else: ?><a href="<?=$r?>auth.php">Log in</a><a class="btn sm" href="<?=$r?>auth.php?tab=reg">Sign up</a><?php endif; ?>
</nav></header><main class="wrap">
<?php if($f): ?><div class="msg <?=$f[1]?>"><?=e($f[0])?></div><?php endif; }
function foot(){echo '</main><footer class="foot">EventHub · Event Booking &amp; Management System</footer></body></html>';}
function admin_nav(){$p=basename($_SERVER['PHP_SELF']);$l=['index.php'=>'Dashboard','events.php'=>'Events','attendees.php'=>'Attendees & check-in','users.php'=>'Users'];
echo '<div class="tabs">';foreach($l as $k=>$v)echo "<a class='".($p==$k?'on':'')."' href='$k'>$v</a>";echo '</div>';}

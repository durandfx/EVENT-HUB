<?php require 'inc.php';require 'mail.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=$pdo->prepare('SELECT * FROM users WHERE email=?');$s->execute([strtolower(trim($_POST['email']??''))]);$u=$s->fetch();$note='';
 if($u){$a='abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';$pw='';for($i=0;$i<10;$i++)$pw.=$a[random_int(0,strlen($a)-1)];
  $pdo->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($pw,PASSWORD_DEFAULT),$u['id']]);
  [$ok,$m]=mail_send($u['email'],$u['name'],'Your new EventHub password','<div style="font-family:Arial,sans-serif"><p>Hello '.e($u['name']).',</p><p>Your new password is: <b style="font-size:18px">'.$pw.'</b></p><p>Log in with it, then change it under <b>Account</b>. If you did not ask for this, please change your password straight away.</p></div>');
  if(SMTP_USER==='')$note=' (Email is not configured: the message is in the outbox folder.)';elseif(!$ok)$note=' '.$m;}
 flash('If that email is registered, a new password has been sent to it.'.$note);header('Location:forgot.php');exit;}
head('Forgot password');?><div class="auth card"><h1>Forgot your password?</h1><p class="muted">Enter your account email and we will send you a new password.</p>
<form method="post"><label>Email<input type="email" name="email" required></label><button class="btn">Send new password</button></form><p><a href="auth.php">Back to log in</a></p></div><?php foot();

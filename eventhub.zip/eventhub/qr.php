<?php require 'inc.php';
$c=preg_replace('/[^A-Z0-9]/','',strtoupper($_GET['code']??''));
if(!$c||strlen($c)>20){http_response_code(404);exit;}
header('Content-Type:image/png');echo qr_png($c,6);

<?php require 'inc.php';
$next=$_GET['next']??'index.php'; if(!preg_match('~^/[^/]~',$next))$next='index.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $em=strtolower(trim($_POST['email']??''));$pw=$_POST['password']??'';
 if($_POST['do']==='reg'){
  $nm=trim($_POST['name']??'');
  if(!$nm||!filter_var($em,FILTER_VALIDATE_EMAIL)||strlen($pw)<6)flash('Enter your name, a valid email and a password of at least 6 characters.','err');
  else{$c=$pdo->prepare('SELECT id FROM users WHERE email=?');$c->execute([$em]);
   if($c->fetch())flash('That email is already registered. Log in instead.','err');
   else{$pdo->prepare('INSERT INTO users(name,email,password) VALUES(?,?,?)')->execute([$nm,$em,password_hash($pw,PASSWORD_DEFAULT)]);
    $_SESSION['u']=['id'=>$pdo->lastInsertId(),'name'=>$nm,'role'=>'user'];header("Location:$next");exit;}}
 }else{
  $s=$pdo->prepare('SELECT * FROM users WHERE email=?');$s->execute([$em]);$u=$s->fetch();
  if($u&&password_verify($pw,$u['password'])){$_SESSION['u']=['id'=>$u['id'],'name'=>$u['name'],'role'=>$u['role']];
   header('Location:'.($u['role']==='admin'&&$next==='index.php'?'admin/index.php':$next));exit;}
  flash('Wrong email or password.','err');
 }
 header('Location:auth.php?tab='.$_POST['do'].'&next='.urlencode($next));exit;
}
$reg=($_GET['tab']??'')==='reg'; head($reg?'Sign up':'Log in');?>
<div class="auth card"><h1><?=$reg?'Create your account':'Welcome back'?></h1>
<form method="post"><input type="hidden" name="do" value="<?=$reg?'reg':'login'?>">
<?php if($reg): ?><label>Full name<input name="name" required></label><?php endif; ?>
<label>Email<input type="email" name="email" required></label>
<label>Password<input type="password" name="password" required></label>
<button class="btn"><?=$reg?'Sign up':'Log in'?></button></form><?php if(!$reg): ?><p><a href="forgot.php">Forgot your password?</a></p><?php endif; ?>
<p class="muted"><?=$reg?'Already registered? <a href="auth.php">Log in</a>':'New here? <a href="auth.php?tab=reg">Create an account</a>'?></p></div>
<?php foot();

<?php require 'inc.php';need_login();$id=me()['id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 if($_POST['do']==='profile'){$n=trim($_POST['name']);$em=strtolower(trim($_POST['email']));$c=$pdo->prepare('SELECT id FROM users WHERE email=? AND id<>?');$c->execute([$em,$id]);
  if(!$n||!filter_var($em,FILTER_VALIDATE_EMAIL))flash('Enter a name and a valid email.','err');elseif($c->fetch())flash('That email is used by another account.','err');
  else{$pdo->prepare('UPDATE users SET name=?,email=? WHERE id=?')->execute([$n,$em,$id]);$_SESSION['u']['name']=$n;flash('Profile updated.');}}
 else{$s=$pdo->prepare('SELECT password FROM users WHERE id=?');$s->execute([$id]);
  if(!password_verify($_POST['old'],$s->fetchColumn()))flash('Your current password is wrong.','err');
  elseif(strlen($_POST['new'])<6)flash('The new password must have at least 6 characters.','err');
  elseif($_POST['new']!==$_POST['new2'])flash('The two new passwords do not match.','err');
  else{$pdo->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($_POST['new'],PASSWORD_DEFAULT),$id]);flash('Password changed.');}}
 header('Location:account.php');exit;}
$s=$pdo->prepare('SELECT * FROM users WHERE id=?');$s->execute([$id]);$u=$s->fetch();head('Account');?>
<h1>My account</h1><div class="form2"><form method="post" class="card"><input type="hidden" name="do" value="profile"><h3>Profile</h3>
<label>Full name<input name="name" value="<?=e($u['name'])?>" required></label><label>Email<input type="email" name="email" value="<?=e($u['email'])?>" required></label><button class="btn">Save profile</button></form>
<form method="post" class="card"><input type="hidden" name="do" value="pw"><h3>Change password</h3><label>Current password<input type="password" name="old" required></label>
<label>New password<input type="password" name="new" minlength="6" required></label><label>Repeat new password<input type="password" name="new2" required></label><button class="btn">Change password</button></form></div><?php foot();

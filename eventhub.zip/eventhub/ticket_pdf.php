<?php require 'inc.php';require 'pdf.php';need_login();
$r=tickets_of($pdo,'k.code=?',[strtoupper(trim($_GET['code']??''))]);
if(!$r||($r[0]['user_id']!=me()['id']&&me()['role']!=='admin')){http_response_code(404);exit('Ticket not found.');}
header('Content-Type:application/pdf');header('Content-Disposition:inline; filename="Ticket-'.$r[0]['code'].'.pdf"');echo ticket_pdf($r[0]);

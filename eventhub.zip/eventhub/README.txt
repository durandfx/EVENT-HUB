EventHub - Event Booking & Management System (PHP + MySQL)
1. Copy this folder to C:\xampp\htdocs\eventhub
2. Start Apache and MySQL in XAMPP
3. phpMyAdmin > Import > database.sql  (re-importing resets all data)
4. Open http://localhost/eventhub/
Admin login: admin@eventhub.com / password   (change it under Account)
PAYMENT: demo only (MTN Mobile Money, Airtel Money, VISA). Nothing is charged; only the method and last digits are stored.
UPGRADING without losing data? Run in phpMyAdmin (SQL tab): ALTER TABLE orders ADD pay_method VARCHAR(40) NULL, ADD pay_detail VARCHAR(60) NULL, ADD pay_ref VARCHAR(30) NULL;
EMAIL: edit the top of inc.php (SMTP_USER = Gmail address, SMTP_PASS = Google App password).
While SMTP_USER is empty, emails and PDFs are saved in /outbox so you can test.
Needs the mbstring and zlib PHP extensions (both enabled by default in XAMPP).

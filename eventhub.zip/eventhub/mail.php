<?php
use PHPMailer\PHPMailer\PHPMailer;
require_once __DIR__.'/pdf.php';
// $files: ['name.pdf'=>binary]   $inline: ['cid'=>png binary]
function mail_send($to,$name,$subject,$html,$files=[],$inline=[]){
 if(SMTP_USER===''){$d=__DIR__.'/outbox';if(!is_dir($d))mkdir($d);$b=$d.'/'.date('Ymd-His').'-'.preg_replace('/[^a-z0-9@._-]/i','_',$to);
  foreach($inline as $id=>$png)$html=str_replace("cid:$id",'data:image/png;base64,'.base64_encode($png),$html);
  file_put_contents("$b.html",$html);foreach($files as $fn=>$bin)file_put_contents("$b-$fn",$bin);
  return [true,'Email is not configured, so a copy was saved in the outbox folder (set SMTP_USER and SMTP_PASS in inc.php to send real emails).'];}
 try{foreach(['Exception','PHPMailer','SMTP'] as $f)require_once __DIR__."/lib/PHPMailer/$f.php";
  $m=new PHPMailer(true);$m->isSMTP();$m->Host=SMTP_HOST;$m->SMTPAuth=true;$m->Username=SMTP_USER;$m->Password=SMTP_PASS;$m->SMTPSecure=PHPMailer::ENCRYPTION_STARTTLS;$m->Port=SMTP_PORT;$m->CharSet='UTF-8';
  $m->setFrom(SMTP_USER,MAIL_FROM_NAME);$m->addAddress($to,$name);$m->isHTML(true);$m->Subject=$subject;$m->Body=$html;$m->AltBody=trim(strip_tags(str_replace(['<br>','</p>','</tr>'],"\n",$html)));
  foreach($inline as $id=>$png)$m->addStringEmbeddedImage($png,$id,"$id.png",'base64','image/png');
  foreach($files as $fn=>$bin)$m->addStringAttachment($bin,$fn,'base64','application/pdf');
  $m->send();return [true,"Email sent to $to."];
 }catch(Throwable $x){return [false,'The email failed: '.$x->getMessage()];}}
function send_tickets($pdo,$oid){
 $tk=tickets_of($pdo,'k.order_id=?',[$oid]);if(!$tk)return [false,'Order not found.'];$o=$tk[0];$files=[];$inl=[];
 $h='<div style="font-family:Arial,sans-serif;max-width:580px;margin:auto;color:#10262e"><h2 style="color:#0f5c63">Your tickets are confirmed</h2><p>Hello '.e($o['buyer']).',</p><p>Thank you for booking <b>'.e($o['title']).'</b>. Every guest has their own ticket below, and each one is also attached as a separate PDF.</p>'
  .'<p>'.date('l, j F Y \a\t H:i',strtotime($o['event_date'])).'<br>'.e($o['venue']).', '.e($o['city']).'<br>Order #'.$oid.($o['pay_method']?' · Paid '.money($o['total']).' with '.e($o['pay_method']).' '.e($o['pay_detail']).' · Ref '.e($o['pay_ref']):'').'</p>';
 foreach($tk as $i=>$k){$inl["qr$i"]=qr_png($k['code'],5);$files["Ticket-{$k['code']}.pdf"]=ticket_pdf($k);
  $h.='<table style="width:100%;border:2px dashed #0f5c63;margin:12px 0"><tr><td style="padding:14px"><span style="color:#5d7078;font-size:12px">GUEST</span><br><b style="font-size:18px">'.e($k['holder']).'</b><br><br><b>'.e($k['tier']).'</b><br><span style="font-size:18px;color:#0f5c63"><b>'.e(seat_label($k)).'</b></span><br><span style="color:#5d7078;font-size:12px">Code: '.e($k['code']).'</span></td><td style="padding:14px;text-align:center;width:150px"><img src="cid:qr'.$i.'" width="140" height="140" alt="QR"></td></tr></table>';}
 return mail_send($o['email'],$o['buyer'],'Your '.count($tk).' ticket(s) for '.$o['title'],$h.'<p>Show the QR code at the entrance. Each code works once.</p></div>',$files,$inl);}

<?php require 'inc.php';require 'mail.php';need_login();$uid=me()['id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(isset($_POST['cancel'])){
  $n=$pdo->prepare("UPDATE orders o JOIN events e ON e.id=o.event_id SET o.status='cancelled' WHERE o.id=? AND o.user_id=? AND o.status='confirmed' AND e.event_date>NOW() AND NOT EXISTS(SELECT 1 FROM tickets k WHERE k.order_id=o.id AND k.checked_in=1)");
  $n->execute([(int)$_POST['cancel'],$uid]);flash($n->rowCount()?'Order cancelled.':'This order cannot be cancelled.',$n->rowCount()?'ok':'err');}
 elseif(isset($_POST['resend'])){$c=$pdo->prepare('SELECT id FROM orders WHERE id=? AND user_id=? AND status="confirmed"');$c->execute([(int)$_POST['resend'],$uid]);
  if($c->fetch()){[$ok,$m]=send_tickets($pdo,(int)$_POST['resend']);flash($m,$ok?'ok':'err');}}
 header('Location:my_tickets.php');exit;}
$s=$pdo->prepare('SELECT o.*,e.title,e.event_date,e.venue,(SELECT COUNT(*) FROM tickets WHERE order_id=o.id) n FROM orders o JOIN events e ON e.id=o.event_id WHERE o.user_id=? ORDER BY o.id DESC');$s->execute([$uid]);
head('My tickets');?><h1>My tickets</h1>
<?php foreach($s as $o): ?><div class="card row"><div><h3><?=e($o['title'])?></h3><p class="muted"><?=date('D j M Y, H:i',strtotime($o['event_date']))?> · <?=e($o['venue'])?><br>Order #<?=$o['id']?> · <?=$o['n']?> ticket(s) · <?=money($o['total'])?></p></div>
<div><span class="pill <?=$o['status']?>"><?=$o['status']?></span>
<?php if($o['status']==='confirmed'): ?><a class="btn sm" href="ticket.php?order=<?=$o['id']?>">View tickets</a>
<form method="post" style="display:inline"><button class="btn sm ghost" name="resend" value="<?=$o['id']?>">Email again</button></form>
<?php if(strtotime($o['event_date'])>time()): ?><form method="post" style="display:inline" onsubmit="return confirm('Cancel this order?')"><button class="btn sm ghost" name="cancel" value="<?=$o['id']?>">Cancel</button></form><?php endif; endif; ?></div></div>
<?php endforeach; if(!$s->rowCount()): ?><p class="muted">You have no tickets yet. <a href="index.php">Find an event</a>.</p><?php endif; foot();

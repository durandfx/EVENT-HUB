<?php require 'inc.php';require 'mail.php';need_login();
function luhn($n){$s=0;$a=false;for($i=strlen($n)-1;$i>=0;$i--){$d=(int)$n[$i];if($a){$d*=2;if($d>9)$d-=9;}$s+=$d;$a=!$a;}return $s%10==0;}
$c=$_SESSION['cart']??null;if(!$c){header('Location:index.php');exit;}
$s=$pdo->prepare("SELECT * FROM events WHERE id=? AND status='published'");$s->execute([$c['event']]);$ev=$s->fetch();
if(!$ev||strtotime($ev['event_date'])<time()){unset($_SESSION['cart']);flash('This event is no longer available.','err');header('Location:index.php');exit;}
$s=$pdo->prepare('SELECT * FROM ticket_types WHERE event_id=?');$s->execute([$ev['id']]);$T=[];foreach($s as $t)$T[$t['id']]=$t;
$total=0;foreach($c['items'] as [$tid,$g]){if(!isset($T[$tid])){unset($_SESSION['cart']);header('Location:index.php');exit;}$total+=$T[$tid]['price'];}
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(isset($_POST['back'])){unset($_SESSION['cart']);header('Location:event.php?id='.$ev['id']);exit;}
 $m=$_POST['method']??'';$err='';$label='Free';$detail='';
 if($total>0){
  if($m==='mtn'||$m==='airtel'){
   $p=preg_replace('/^\+?250/','0',preg_replace('/[\s\-]/','',$_POST['phone']??''));
   if(!preg_match($m==='mtn'?'/^07[89]\d{7}$/':'/^07[23]\d{7}$/',$p))$err=$m==='mtn'?'Enter a valid MTN Rwanda number (078… or 079…).':'Enter a valid Airtel Rwanda number (072… or 073…).';
   $label=$m==='mtn'?'MTN Mobile Money':'Airtel Money';$detail=substr($p,0,4).'***'.substr($p,-3);
  }elseif($m==='visa'){
   $n=preg_replace('/\D/','',$_POST['card']??'');$exp=trim($_POST['exp']??'');$cv=trim($_POST['cvv']??'');
   if(trim($_POST['holder']??'')==='')$err='Enter the name on the card.';
   elseif(!preg_match('/^4\d{15}$/',$n)||!luhn($n))$err='Enter a valid VISA card number (16 digits starting with 4).';
   elseif(!preg_match('~^(0[1-9]|1[0-2])\s*/\s*(\d{2})$~',$exp,$mm)||mktime(0,0,0,$mm[1]+1,1,2000+$mm[2])<=time())$err='The card expiry date is invalid or in the past (use MM/YY).';
   elseif(!preg_match('/^\d{3}$/',$cv))$err='Enter the 3-digit security code (CVV).';
   $label='VISA Card';$detail='**** '.substr($n,-4); // only the last 4 digits are kept
  }else $err='Choose how you want to pay.';
 }
 if(!$err){
  $pdo->beginTransaction();$pdo->prepare('SELECT id FROM events WHERE id=? FOR UPDATE')->execute([$ev['id']]);
  $s=$pdo->prepare("SELECT t.id,".TLEFT." AS l FROM ticket_types t WHERE t.event_id=?");$s->execute([$ev['id']]);$L=$s->fetchAll(PDO::FETCH_KEY_PAIR);
  $need=[];foreach($c['items'] as [$tid,$g])$need[$tid]=($need[$tid]??0)+1;$free=[];
  foreach($need as $tid=>$q){$u=$pdo->prepare("SELECT DISTINCT k.unit_no FROM tickets k JOIN orders o ON o.id=k.order_id WHERE k.type_id=? AND o.status='confirmed'");$u->execute([$tid]);
   $free[$tid]=array_values(array_diff(range(1,$T[$tid]['seats']),$u->fetchAll(PDO::FETCH_COLUMN)));
   if($q>$L[$tid]||count($free[$tid])<$q){$err="Sorry, {$T[$tid]['name']} has fewer places left than you chose. You have not been charged.";break;}}
  if($err){$pdo->rollBack();unset($_SESSION['cart']);flash($err,'err');header('Location:event.php?id='.$ev['id']);exit;}
  $ref='DEMO-'.strtoupper(bin2hex(random_bytes(4)));
  $pdo->prepare('INSERT INTO orders(user_id,event_id,total,pay_method,pay_detail,pay_ref) VALUES(?,?,?,?,?,?)')->execute([me()['id'],$ev['id'],$total,$label,$detail,$ref]);$oid=$pdo->lastInsertId();
  $ins=$pdo->prepare('INSERT INTO tickets(order_id,type_id,code,holder,unit_no,guest_idx) VALUES(?,?,?,?,?,?)');
  foreach($c['items'] as [$tid,$g]){$unit=array_shift($free[$tid]);foreach($g as $j=>$name)$ins->execute([$oid,$tid,strtoupper(bin2hex(random_bytes(5))),$name,$unit,$j+1]);}
  $pdo->commit();unset($_SESSION['cart']);[$ok,$msg]=send_tickets($pdo,$oid);
  flash('Payment successful. '.$msg,$ok?'ok':'err');header("Location:ticket.php?order=$oid");exit;}
 flash($err,'err');
}
$pv=fn($k)=>e($_POST[$k]??'');
head('Payment');?>
<h1>Payment</h1><div class="detail" style="grid-template-columns:1fr 340px">
<div><?php if($total>0): ?><form method="post" id="pay"><h2 style="margin-top:0">How do you want to pay?</h2>
<div class="methods">
<label class="method"><input type="radio" name="method" value="mtn" <?=($_POST['method']??'')==='mtn'?'checked':''?>><span class="logo-m mtn">MTN</span>Mobile Money</label>
<label class="method"><input type="radio" name="method" value="airtel" <?=($_POST['method']??'')==='airtel'?'checked':''?>><span class="logo-m air">airtel</span>Airtel Money</label>
<label class="method"><input type="radio" name="method" value="visa" <?=($_POST['method']??'')==='visa'?'checked':''?>><span class="logo-m visa">VISA</span>Card</label></div>
<div class="card pg" data-for="mtn airtel" hidden><label>Mobile money number (Rwanda)<input name="phone" inputmode="tel" placeholder="07X XXX XXXX" value="<?=$pv('phone')?>" required></label>
<p class="muted">In a real payment you would get a prompt on this phone to enter your PIN.</p></div>
<div class="card pg" data-for="visa" hidden><label>Name on card<input name="holder" autocomplete="off" value="<?=$pv('holder')?>" required></label>
<label>Card number<input name="card" id="card" inputmode="numeric" maxlength="19" placeholder="4111 1111 1111 1111" autocomplete="off" required></label>
<div class="form2"><label>Expiry (MM/YY)<input name="exp" maxlength="5" placeholder="12/28" autocomplete="off" required></label><label>CVV<input name="cvv" maxlength="3" inputmode="numeric" placeholder="123" autocomplete="off" required></label></div></div>
<p class="demo"><b>Demo payment.</b> No money is charged and nothing is sent to MTN, Airtel or VISA. Use any valid-looking details. For VISA you can use the test card 4111 1111 1111 1111 with a future expiry. Please do not enter a real card.</p>
<button class="btn wide" id="go">Pay <?=money($total)?></button></form>
<?php else: ?><form method="post"><h2 style="margin-top:0">This event is free</h2><p class="muted">No payment is needed.</p><button class="btn wide">Confirm free booking</button></form><?php endif; ?>
<form method="post" style="margin-top:10px"><button class="btn ghost wide" name="back" value="1" formnovalidate>Change my tickets</button></form></div>
<aside class="card"><h3><?=e($ev['title'])?></h3><p class="muted"><?=date('D j M Y · H:i',strtotime($ev['event_date']))?><br><?=e($ev['venue'])?></p>
<?php foreach($c['items'] as [$tid,$g]): $t=$T[$tid]; ?><p style="border-top:1px solid var(--line);padding-top:8px"><b><?=e($t['name'])?></b> · <?=money($t['price'])?><br><span class="muted"><?=e(implode(', ',$g))?></span></p><?php endforeach; ?>
<p class="row" style="border-top:2px solid var(--ink);padding-top:8px"><b>Total</b><b><?=money($total)?></b></p></aside></div>
<script>function sel(){const m=(document.querySelector('input[name=method]:checked')||{}).value;document.querySelectorAll('.pg').forEach(x=>{const on=x.dataset.for.split(' ').includes(m);x.hidden=!on;x.querySelectorAll('input').forEach(i=>i.disabled=!on)});}
document.querySelectorAll('input[name=method]').forEach(r=>r.addEventListener('change',sel));sel();
const cd=document.getElementById('card');if(cd)cd.addEventListener('input',()=>{cd.value=cd.value.replace(/\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim()});
const pf=document.getElementById('pay');if(pf)pf.addEventListener('submit',()=>{const b=document.getElementById('go');setTimeout(()=>{b.disabled=true;b.textContent='Processing payment…'},0)});</script>
<?php foot();

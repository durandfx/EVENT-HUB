<?php require 'inc.php';need_login();
$tk=tickets_of($pdo,'k.order_id=?',[(int)($_GET['order']??0)]);
if(!$tk||($tk[0]['user_id']!=me()['id']&&me()['role']!=='admin')){http_response_code(404);head('Ticket');echo '<p>Ticket not found.</p>';foot();exit;}
head('Tickets');?><h1>Order #<?=$tk[0]['order_id']??(int)$_GET['order']?> <span class="pill <?=$tk[0]['status']?>"><?=$tk[0]['status']?></span></h1><p class="muted">Each guest has their own ticket.<?php if($tk[0]['pay_method']): ?> Paid <?=money($tk[0]['total'])?> with <?=e($tk[0]['pay_method'])?> <?=e($tk[0]['pay_detail'])?> · Ref <?=e($tk[0]['pay_ref'])?><?php endif; ?></p>
<?php foreach($tk as $k): ?><div class="ticket"><div class="t-main"><span class="tag"><?=e($k['tier'])?></span><h2><?=e($k['title'])?></h2>
<p><?=date('l, j F Y · H:i',strtotime($k['event_date']))?><br><?=e($k['venue'])?>, <?=e($k['city'])?></p>
<p class="muted">Guest</p><p style="margin-top:-12px"><b style="font-size:1.2rem"><?=e($k['holder'])?></b></p><p class="seat"><?=e(seat_label($k))?></p>
<?php if($k['checked_in']): ?><p class="warn"><b>Already used</b></p><?php endif; ?><a href="ticket_pdf.php?code=<?=e($k['code'])?>" target="_blank">Download PDF</a></div>
<div class="t-qr"><img src="qr.php?code=<?=e($k['code'])?>" width="150" height="150" alt="QR code"><code><?=e($k['code'])?></code></div></div>
<?php endforeach; ?><p class="center"><button class="btn" onclick="print()">Print tickets</button> <a class="btn ghost" href="my_tickets.php">All orders</a></p>
<?php foot();

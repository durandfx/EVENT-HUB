<?php require 'inc.php';
$q=trim($_GET['q']??'');$c=$_GET['cat']??'';$p=[];
$sql="SELECT e.*,(SELECT MIN(price) FROM ticket_types WHERE event_id=e.id) minp,(SELECT COALESCE(SUM(t.seats-(SELECT COUNT(DISTINCT k.unit_no) FROM tickets k JOIN orders o ON o.id=k.order_id WHERE k.type_id=t.id AND o.status='confirmed')),0) FROM ticket_types t WHERE t.event_id=e.id) seats FROM events e WHERE e.status='published' AND e.event_date>=NOW()";
if($q){$sql.=" AND (e.title LIKE ? OR e.city LIKE ? OR e.venue LIKE ?)";$p=["%$q%","%$q%","%$q%"];}
if($c){$sql.=" AND e.category=?";$p[]=$c;}
$st=$pdo->prepare($sql." ORDER BY e.event_date");$st->execute($p);$ev=$st->fetchAll();
$cats=$pdo->query("SELECT DISTINCT category FROM events WHERE status='published' ORDER BY 1")->fetchAll(PDO::FETCH_COLUMN);
head('Find events');?>
<section class="hero"><h1>Your next event is a ticket away.</h1><p>Tap a flyer to book. Your QR tickets arrive by email.</p>
<form class="search"><input name="q" value="<?=e($q)?>" placeholder="Search by event, venue or city"><select name="cat"><option value="">All categories</option>
<?php foreach($cats as $k): ?><option <?=$k==$c?'selected':''?>><?=e($k)?></option><?php endforeach; ?></select><button class="btn">Search</button></form></section>
<div class="posters">
<?php foreach($ev as $x): $d=strtotime($x['event_date']); ?>
<a class="poster" href="event.php?id=<?=$x['id']?>"><?=flyer($x)?><?php if($x['seats']<=0): ?><span class="badge">Sold out</span><?php endif; ?>
<div class="info"><h3><?=e($x['title'])?></h3><p class="muted"><?=date('D j M · H:i',$d)?><br><?=e($x['city'])?></p>
<div class="row"><b><?=$x['minp']===null?'':($x['minp']>0?'From '.money($x['minp']):'Free')?></b><span class="btn sm">Book</span></div></div></a>
<?php endforeach; if(!$ev): ?><p class="muted">No upcoming events match your search. Clear the filters to see everything.</p><?php endif; ?></div>
<?php foot();

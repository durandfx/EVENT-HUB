<?php require '../inc.php';need_admin();$me=me()['id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(isset($_POST['del'])){$d=(int)$_POST['del'];if($d==$me)flash('You cannot delete your own account.','err');else{$pdo->prepare('DELETE FROM users WHERE id=?')->execute([$d]);flash('User deleted with their orders.');}header('Location:users.php');exit;}
 $id=(int)$_POST['id'];$n=trim($_POST['name']);$em=strtolower(trim($_POST['email']));$role=$_POST['role']==='admin'?'admin':'user';$pw=$_POST['password'];if($id==$me)$role='admin';
 $c=$pdo->prepare('SELECT id FROM users WHERE email=? AND id<>?');$c->execute([$em,$id]);
 if(!$n||!filter_var($em,FILTER_VALIDATE_EMAIL))flash('Enter a name and a valid email.','err');elseif($c->fetch())flash('That email is used by another account.','err');
 elseif(($pw!==''||!$id)&&strlen($pw)<6)flash('Password must have at least 6 characters.','err');
 else{if($id){$pdo->prepare('UPDATE users SET name=?,email=?,role=? WHERE id=?')->execute([$n,$em,$role,$id]);if($pw!=='')$pdo->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($pw,PASSWORD_DEFAULT),$id]);if($id==$me)$_SESSION['u']['name']=$n;flash('User updated.');}
  else{$pdo->prepare('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)')->execute([$n,$em,password_hash($pw,PASSWORD_DEFAULT),$role]);flash('User created.');}}
 header('Location:users.php');exit;}
$ed=null;if(isset($_GET['edit'])){$s=$pdo->prepare('SELECT * FROM users WHERE id=?');$s->execute([(int)$_GET['edit']]);$ed=$s->fetch();}
$q=trim($_GET['q']??'');$s=$pdo->prepare('SELECT u.*,(SELECT COUNT(*) FROM orders WHERE user_id=u.id) n FROM users u WHERE name LIKE ? OR email LIKE ? ORDER BY u.id DESC');$s->execute(["%$q%","%$q%"]);
head('Users','../');admin_nav();$v=fn($k)=>e($ed[$k]??'');?>
<h1><?=$ed?'Edit user #'.$ed['id']:'Add a user'?></h1>
<form method="post" class="card form2"><input type="hidden" name="id" value="<?=$ed['id']??0?>"><label>Full name<input name="name" value="<?=$v('name')?>" required></label><label>Email<input type="email" name="email" value="<?=$v('email')?>" required></label>
<label>Role<select name="role"><option value="user">User</option><option value="admin" <?=($ed['role']??'')==='admin'?'selected':''?>>Admin</option></select></label>
<label><?=$ed?'New password (leave empty to keep the current one)':'Password'?><input type="text" name="password" autocomplete="off" <?=$ed?'':'required'?>></label>
<div class="full"><button class="btn"><?=$ed?'Save user':'Create user'?></button> <?php if($ed): ?><a class="btn ghost" href="users.php">Cancel</a><?php endif; ?></div></form>
<form class="inline" style="margin:16px 0"><input name="q" value="<?=e($q)?>" placeholder="Search name or email"><button class="btn sm">Search</button></form>
<div class="scroll"><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Orders</th><th>Joined</th><th></th></tr>
<?php foreach($s as $u): ?><tr><td><?=e($u['name'])?></td><td><?=e($u['email'])?></td><td><span class="pill <?=$u['role']==='admin'?'confirmed':'draft'?>"><?=$u['role']?></span></td><td><?=$u['n']?></td><td><?=date('d M Y',strtotime($u['created_at']))?></td>
<td><a href="?edit=<?=$u['id']?>">Edit</a><?php if($u['id']!=$me): ?> <form method="post" style="display:inline" onsubmit="return confirm('Delete this user and all their orders?')"><button class="link" name="del" value="<?=$u['id']?>">Delete</button></form><?php endif; ?></td></tr><?php endforeach; ?></table></div>
<?php foot();

<?php require '../inc.php';need_admin();
$eid=(int)($_GET['event']??0);
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['code'])){
 $c=strtoupper(trim($_POST['code']));
 $u=$pdo->prepare("UPDATE tickets k JOIN orders o ON o.id=k.order_id SET k.checked_in=1,k.checked_in_at=NOW() WHERE k.code=? AND o.status='confirmed' AND k.checked_in=0");$u->execute([$c]);
 $r=tickets_of($pdo,'k.code=?',[$c])[0]??null;
 if($u->rowCount())flash("Valid: {$r['holder']} · {$r['tier']} · ".seat_label($r)." · {$r['title']}");
 else flash(!$r?'Ticket not found.':($r['status']==='cancelled'?'This order was cancelled.':'Already checked in earlier.'),'err');
 header("Location:attendees.php?event=$eid");exit;}
$rows=tickets_of($pdo,"o.status='confirmed'".($eid?' AND o.event_id='.$eid:''),[]);
usort($rows,fn($a,$b)=>[$a['title'],$a['tier'],$a['unit_no'],$a['guest_idx']]<=>[$b['title'],$b['tier'],$b['unit_no'],$b['guest_idx']]);
if(isset($_GET['csv'])){header('Content-Type:text/csv');header('Content-Disposition:attachment;filename=attendees.csv');$o=fopen('php://output','w');
 fputcsv($o,['Event','Ticket type','Seat / table','Guest','Buyer','Buyer email','Code','Checked in']);foreach($rows as $r)fputcsv($o,[$r['title'],$r['tier'],seat_label($r),$r['holder'],$r['buyer'],$r['email'],$r['code'],$r['checked_in']?'Yes':'No']);exit;}
$evs=$pdo->query('SELECT id,title FROM events ORDER BY event_date DESC')->fetchAll();
head('Attendees','../');admin_nav();?><h1>Attendees &amp; check-in</h1>
<div class="card row"><form method="post" class="inline"><input name="code" placeholder="Scan or type ticket code" autofocus autocomplete="off" required><button class="btn">Check in</button></form>
<form class="inline"><select name="event" onchange="this.form.submit()"><option value="0">All events</option><?php foreach($evs as $x): ?><option value="<?=$x['id']?>" <?=$x['id']==$eid?'selected':''?>><?=e($x['title'])?></option><?php endforeach; ?></select>
<a class="btn ghost" href="?event=<?=$eid?>&csv=1">Export CSV</a></form></div>
<p class="muted"><?=count($rows)?> ticket(s) · <?=count(array_filter($rows,fn($r)=>$r['checked_in']))?> checked in</p>
<div class="scroll"><table><tr><th>Event</th><th>Type</th><th>Seat / table</th><th>Guest</th><th>Buyer</th><th>Code</th><th>Status</th></tr>
<?php foreach($rows as $r): ?><tr><td><?=e($r['title'])?></td><td><?=e($r['tier'])?></td><td><b><?=e(seat_label($r))?></b></td><td><?=e($r['holder'])?></td><td><?=e($r['buyer'])?><br><span class="muted"><?=e($r['email'])?></span></td><td><code><?=e($r['code'])?></code></td>
<td><?php if($r['checked_in']): ?><span class="pill confirmed">In · <?=date('H:i',strtotime($r['checked_in_at']))?></span><?php else: ?><form method="post" style="display:inline"><button class="btn sm" name="code" value="<?=e($r['code'])?>">Check in</button></form><?php endif; ?></td></tr><?php endforeach; ?></table></div>
<?php foot();

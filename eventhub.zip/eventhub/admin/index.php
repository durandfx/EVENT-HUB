<?php require '../inc.php';need_admin();
$n=fn($q)=>$pdo->query($q)->fetchColumn();$C="FROM tickets k JOIN orders o ON o.id=k.order_id WHERE o.status='confirmed'";
$st=['Events'=>$n("SELECT COUNT(*) FROM events"),'Tickets sold'=>$n("SELECT COUNT(*) $C"),'Revenue'=>'RWF '.number_format($n("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='confirmed'")),
'Checked in'=>$n("SELECT COUNT(*) $C AND k.checked_in=1"),'Members'=>$n("SELECT COUNT(*) FROM users WHERE role='user'")];
$ev=$pdo->query("SELECT e.id,e.title,e.event_date,(SELECT COALESCE(SUM(seats*group_size),0) FROM ticket_types WHERE event_id=e.id) cap,(SELECT COUNT(*) FROM tickets k JOIN orders o ON o.id=k.order_id WHERE o.event_id=e.id AND o.status='confirmed') sold,(SELECT COALESCE(SUM(total),0) FROM orders WHERE event_id=e.id AND status='confirmed') rev FROM events e ORDER BY e.event_date DESC")->fetchAll();
$rc=$pdo->query("SELECT o.*,u.name,e.title,(SELECT COUNT(*) FROM tickets WHERE order_id=o.id) n FROM orders o JOIN users u ON u.id=o.user_id JOIN events e ON e.id=o.event_id ORDER BY o.id DESC LIMIT 8")->fetchAll();
head('Dashboard','../');admin_nav();?><h1>Dashboard</h1>
<div class="stats"><?php foreach($st as $k=>$v): ?><div class="card"><b><?=e($v)?></b><span class="muted"><?=$k?></span></div><?php endforeach; ?></div>
<h2>Sales by event</h2><div class="scroll"><table><tr><th>Event</th><th>Date</th><th>Tickets sold</th><th>Revenue</th><th></th></tr>
<?php foreach($ev as $x): $p=$x['cap']?round($x['sold']/$x['cap']*100):0; ?><tr><td><?=e($x['title'])?></td><td><?=date('d M Y',strtotime($x['event_date']))?></td>
<td><div class="bar"><i style="width:<?=$p?>%"></i></div><?=$x['sold']?>/<?=$x['cap']?></td><td><?=money($x['rev'])?></td><td><a href="attendees.php?event=<?=$x['id']?>">Attendees</a></td></tr><?php endforeach; ?></table></div>
<h2>Latest orders</h2><div class="scroll"><table><tr><th>When</th><th>Buyer</th><th>Event</th><th>Tickets</th><th>Total</th><th>Paid with</th><th>Status</th></tr>
<?php foreach($rc as $b): ?><tr><td><?=date('d M, H:i',strtotime($b['created_at']))?></td><td><?=e($b['name'])?></td><td><?=e($b['title'])?></td><td><?=$b['n']?></td><td><?=money($b['total'])?></td><td><?=e($b['pay_method']?:'-')?></td><td><span class="pill <?=$b['status']?>"><?=$b['status']?></span></td></tr><?php endforeach; ?></table></div>
<?php foot();

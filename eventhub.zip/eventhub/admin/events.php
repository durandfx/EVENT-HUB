<?php require '../inc.php';need_admin();
function save_flyer($old){
 if(empty($_FILES['flyer']['name'])||$_FILES['flyer']['error']!==UPLOAD_ERR_OK)return $old;
 $ext=strtolower(pathinfo($_FILES['flyer']['name'],PATHINFO_EXTENSION));
 if(!in_array($ext,['jpg','jpeg','png','webp'])||!@getimagesize($_FILES['flyer']['tmp_name'])){flash('Flyer must be a JPG, PNG or WEBP image.','err');return $old;}
 $dir=dirname(__DIR__).'/uploads';if(!is_dir($dir))mkdir($dir);$n='flyer_'.time().'_'.bin2hex(random_bytes(3)).'.'.$ext;
 move_uploaded_file($_FILES['flyer']['tmp_name'],"$dir/$n");if($old)@unlink("$dir/$old");return $n;}
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(isset($_POST['del'])){$s=$pdo->prepare('SELECT flyer FROM events WHERE id=?');$s->execute([(int)$_POST['del']]);if($f=$s->fetchColumn())@unlink(dirname(__DIR__).'/uploads/'.$f);
  $pdo->prepare('DELETE FROM events WHERE id=?')->execute([(int)$_POST['del']]);flash('Event deleted.');}
 else{$id=(int)$_POST['id'];$old=null;if($id){$s=$pdo->prepare('SELECT flyer FROM events WHERE id=?');$s->execute([$id]);$old=$s->fetchColumn()?:null;}
  $fl=save_flyer($old);
  $f=[trim($_POST['title']),trim($_POST['category']),trim($_POST['venue']),trim($_POST['city']),str_replace('T',' ',$_POST['event_date']),trim($_POST['description']),$fl,$_POST['status']==='draft'?'draft':'published'];
  if($id){$f[]=$id;$pdo->prepare('UPDATE events SET title=?,category=?,venue=?,city=?,event_date=?,description=?,flyer=?,status=? WHERE id=?')->execute($f);}
  else{$pdo->prepare('INSERT INTO events(title,category,venue,city,event_date,description,flyer,status) VALUES(?,?,?,?,?,?,?,?)')->execute($f);$id=$pdo->lastInsertId();}
  $keep=[];$T=$_POST['t_name']??[];
  foreach($T as $i=>$nm){$nm=trim($nm);if($nm==='')continue;$tid=(int)$_POST['t_id'][$i];$pr=max(0,(float)$_POST['t_price'][$i]);$se=max(1,(int)$_POST['t_seats'][$i]);$gs=max(1,(int)$_POST['t_size'][$i]);
   if($tid){$pdo->prepare('UPDATE ticket_types SET name=?,price=?,seats=?,group_size=? WHERE id=? AND event_id=?')->execute([$nm,$pr,$se,$gs,$tid,$id]);$keep[]=$tid;}
   else{$pdo->prepare('INSERT INTO ticket_types(event_id,name,price,seats,group_size) VALUES(?,?,?,?,?)')->execute([$id,$nm,$pr,$se,$gs]);$keep[]=(int)$pdo->lastInsertId();}}
  if(!$keep){$pdo->prepare("INSERT INTO ticket_types(event_id,name,price,seats,group_size) VALUES(?,'Regular',0,100,1)")->execute([$id]);flash('No ticket type was entered, so a free "Regular" ticket was added. Edit it below.','err');}
  else{$o=$pdo->prepare('SELECT id FROM ticket_types WHERE event_id=?');$o->execute([$id]);
   foreach($o->fetchAll(PDO::FETCH_COLUMN) as $tid)if(!in_array($tid,$keep)){$u=$pdo->prepare('SELECT COUNT(*) FROM tickets WHERE type_id=?');$u->execute([$tid]);
    if(!$u->fetchColumn())$pdo->prepare('DELETE FROM ticket_types WHERE id=?')->execute([$tid]);else flash('A ticket type with sales cannot be removed; it was kept.','err');}}
  if(!flash_pending())flash($_POST['id']?'Event updated.':'Event created.');}
 header('Location:events.php');exit;}
function flash_pending(){return isset($_SESSION['f']);}
$ed=null;$rows=[];if(isset($_GET['edit'])){$s=$pdo->prepare('SELECT * FROM events WHERE id=?');$s->execute([(int)$_GET['edit']]);$ed=$s->fetch();
 if($ed){$s=$pdo->prepare('SELECT * FROM ticket_types WHERE event_id=? ORDER BY price,id');$s->execute([$ed['id']]);$rows=$s->fetchAll();}}
if(!$rows)$rows=[['id'=>0,'name'=>'Regular','price'=>5000,'seats'=>100,'group_size'=>1]];
$all=$pdo->query("SELECT e.*,(SELECT COALESCE(SUM(seats*group_size),0) FROM ticket_types WHERE event_id=e.id) cap,(SELECT COUNT(*) FROM tickets k JOIN orders o ON o.id=k.order_id WHERE o.event_id=e.id AND o.status='confirmed') sold,(SELECT GROUP_CONCAT(CONCAT(name,' ',FORMAT(price,0)) SEPARATOR ', ') FROM ticket_types WHERE event_id=e.id) tiers FROM events e ORDER BY event_date DESC")->fetchAll();
head('Events','../');admin_nav();$v=fn($k,$d='')=>e($ed[$k]??$d);?>
<h1><?=$ed?'Edit event':'Create an event'?></h1>
<form method="post" enctype="multipart/form-data" class="card form2"><input type="hidden" name="id" value="<?=$v('id',0)?>">
<label>Title<input name="title" value="<?=$v('title')?>" required></label>
<label>Category<input name="category" value="<?=$v('category')?>" list="c" required><datalist id="c"><option>Conference<option>Music<option>Business<option>Sports<option>Workshop</datalist></label>
<label>Venue<input name="venue" value="<?=$v('venue')?>" required></label><label>City<input name="city" value="<?=$v('city')?>" required></label>
<label>Date and time<input type="datetime-local" name="event_date" value="<?=$ed?date('Y-m-d\TH:i',strtotime($ed['event_date'])):''?>" required></label>
<label>Status<select name="status"><option value="published">Published</option><option value="draft" <?=($ed['status']??'')==='draft'?'selected':''?>>Draft (hidden)</option></select></label>
<label class="full">Flyer image (JPG, PNG or WEBP — portrait works best)<input type="file" name="flyer" accept="image/*"><?php if(!empty($ed['flyer'])): ?><span class="muted">Current flyer is kept unless you upload a new one.</span><?php endif; ?></label>
<label class="full">Description<textarea name="description" rows="3"><?=$v('description')?></textarea></label>
<div class="full"><h3>Ticket types and prices</h3><p class="muted">Add as many as you need (Regular, Silver, Gold, Platinum…). Every price has its own seat count: with “People per ticket” = 1 the seats are numbered 1 to N for that price. With 2 or more (e.g. 5) it is a round table: set the total number of <b>tables</b>, and tickets show Table number and seat. The price is per seat/table, and each guest gets their own ticket.</p>
<div id="tiers"></div><button type="button" class="btn ghost sm" onclick="add()">+ Add ticket type</button></div>
<div class="full"><button class="btn"><?=$ed?'Save changes':'Create event'?></button> <?php if($ed): ?><a class="btn ghost" href="events.php">Cancel</a><?php endif; ?></div></form>
<script>const R=<?=json_encode($rows)?>,B=document.getElementById('tiers');
function add(r={id:0,name:'',price:0,seats:50,group_size:1}){const d=document.createElement('div');d.className='trow';
d.innerHTML='<input type="hidden" name="t_id[]"><label>Name<input name="t_name[]" placeholder="e.g. Gold"></label><label>Price (RWF)<input type="number" min="0" step="100" name="t_price[]"></label><label>Total seats (or tables)<input type="number" min="1" name="t_seats[]"></label><label>People per ticket<input type="number" min="1" name="t_size[]"></label><button type="button" class="link" onclick="this.parentNode.remove()">Remove</button>';
const q=n=>d.querySelector('[name="'+n+'[]"]');q('t_id').value=r.id;q('t_name').value=r.name;q('t_price').value=Math.round(r.price);q('t_seats').value=r.seats;q('t_size').value=r.group_size;B.appendChild(d);}
R.forEach(add);</script>
<h2>All events</h2><div class="scroll"><table><tr><th>Flyer</th><th>Event</th><th>Date</th><th>Ticket types</th><th>Sold</th><th>Status</th><th></th></tr>
<?php foreach($all as $x): ?><tr><td class="thumb"><?=flyer($x,'../')?></td><td><?=e($x['title'])?></td><td><?=date('d M Y H:i',strtotime($x['event_date']))?></td><td><?=e($x['tiers'])?></td><td><?=$x['sold']?>/<?=$x['cap']?></td><td><span class="pill <?=$x['status']?>"><?=$x['status']?></span></td>
<td><a href="?edit=<?=$x['id']?>">Edit</a> <form method="post" style="display:inline" onsubmit="return confirm('Delete this event and all its orders?')"><button class="link" name="del" value="<?=$x['id']?>">Delete</button></form></td></tr><?php endforeach; ?></table></div>
<?php foot();

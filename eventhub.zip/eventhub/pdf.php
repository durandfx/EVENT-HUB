<?php // Minimal PDF ticket writer: no libraries or extensions needed (uses mbstring only for accents)
function pdf_txt($s){$s=mb_convert_encoding((string)$s,'Windows-1252','UTF-8');return str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$s);}
function ticket_pdf($k){
 require_once __DIR__.'/lib/qrcode.php';$c='';$ink='0.063 0.149 0.18';$teal='0.059 0.361 0.388';$gr='0.37 0.44 0.47';
 $T=function($f,$sz,$x,$y,$s,$rgb=null)use(&$c,$ink){$c.="BT /$f $sz Tf ".($rgb?:$ink)." rg $x $y Td (".pdf_txt($s).") Tj ET\n";};
 $c.="$ink rg 0 200 600 60 re f\n0.965 0.718 0.235 rg 0 196 600 4 re f\n";
 $T('F2',8,28,244,'EVENTHUB E-TICKET','0.965 0.718 0.235');$T('F2',20,28,218,mb_strimwidth($k['title'],0,42,'...'),'1 1 1');
 $T('F1',8,28,172,'GUEST',$gr);$T('F2',18,28,152,mb_strimwidth($k['holder'],0,30,'...'));
 $T('F1',8,28,128,'TICKET TYPE',$gr);$T('F2',13,28,112,$k['tier']);
 $T('F1',8,28,92,$k['group_size']>1?'TABLE AND SEAT':'SEAT',$gr);$T('F2',22,28,66,seat_label($k),$teal);
 $T('F1',10,28,40,date('D, j M Y · H:i',strtotime($k['event_date'])));$T('F1',10,28,26,mb_strimwidth($k['venue'].', '.$k['city'],0,56,'...'));
 $q=QRCode::getMinimumQRCode($k['code'],QR_ERROR_CORRECT_LEVEL_M);$n=$q->getModuleCount();$m=max(3,min(6,(int)(150/$n)));$x0=570-$n*$m;$y0=182;
 $c.="0.75 0.8 0.82 RG [3 3] 0 d 0.7 w ".($x0-22)." 12 m ".($x0-22)." 188 l S [] 0 d\n0 g\n";
 for($r=0;$r<$n;$r++)for($j=0;$j<$n;$j++)if($q->isDark($r,$j)){$s=$j;while($j+1<$n&&$q->isDark($r,$j+1))$j++;$c.=($x0+$s*$m).' '.($y0-($r+1)*$m).' '.(($j-$s+1)*$m)." $m re f\n";}
 $T('F3',10,$x0,$y0-$n*$m-14,$k['code']);$T('F1',7,$x0,$y0-$n*$m-26,'Valid for one entry',$gr);
 $o=[1=>'<< /Type /Catalog /Pages 2 0 R >>',2=>'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
 3=>'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 260] /Resources << /Font << /F1 4 0 R /F2 5 0 R /F3 6 0 R >> >> /Contents 7 0 R >>',
 4=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',5=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
 6=>'<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >>',7=>'<< /Length '.strlen($c)." >>\nstream\n$c\nendstream"];
 $p="%PDF-1.4\n";$off=[];foreach($o as $i=>$b){$off[$i]=strlen($p);$p.="$i 0 obj\n$b\nendobj\n";}
 $x=strlen($p);$p.="xref\n0 8\n0000000000 65535 f \n";foreach($off as $v)$p.=sprintf("%010d 00000 n \n",$v);
 return $p."trailer\n<< /Size 8 /Root 1 0 R >>\nstartxref\n$x\n%%EOF";}

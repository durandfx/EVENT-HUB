CREATE DATABASE IF NOT EXISTS eventhub CHARACTER SET utf8mb4;
USE eventhub;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS tickets; DROP TABLE IF EXISTS orders; DROP TABLE IF EXISTS ticket_types; DROP TABLE IF EXISTS bookings; DROP TABLE IF EXISTS events; DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(120) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL, role ENUM('user','admin') DEFAULT 'user', created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE events(
 id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(150) NOT NULL, category VARCHAR(50) NOT NULL,
 venue VARCHAR(150) NOT NULL, city VARCHAR(80) NOT NULL, event_date DATETIME NOT NULL, description TEXT,
 flyer VARCHAR(120) NULL, status ENUM('draft','published') DEFAULT 'published', created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
-- Each event has its own named ticket types. group_size = how many people one ticket admits (5 = a table of 5).
CREATE TABLE ticket_types(
 id INT AUTO_INCREMENT PRIMARY KEY, event_id INT NOT NULL, name VARCHAR(60) NOT NULL, price DECIMAL(10,2) NOT NULL DEFAULT 0,
 seats INT NOT NULL, group_size INT NOT NULL DEFAULT 1,
 FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE);
CREATE TABLE orders(
 id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, event_id INT NOT NULL, total DECIMAL(10,2) NOT NULL,
 status ENUM('confirmed','cancelled') DEFAULT 'confirmed', pay_method VARCHAR(40) NULL, pay_detail VARCHAR(60) NULL, pay_ref VARCHAR(30) NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE);
CREATE TABLE tickets(
 id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, type_id INT NOT NULL, code VARCHAR(20) NOT NULL UNIQUE,
 holder VARCHAR(100) NOT NULL, unit_no INT NOT NULL DEFAULT 1, guest_idx INT NOT NULL DEFAULT 1, checked_in TINYINT(1) DEFAULT 0, checked_in_at DATETIME NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE, FOREIGN KEY(type_id) REFERENCES ticket_types(id) ON DELETE CASCADE);
-- Admin login: admin@eventhub.com / password   (change it after first login)
INSERT INTO users(name,email,password,role) VALUES
('Administrator','admin@eventhub.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin');
INSERT INTO events(id,title,category,venue,city,event_date,description) VALUES
(1,'Kigali Tech Summit','Conference','Kigali Convention Centre','Kigali',DATE_ADD(NOW(),INTERVAL 14 DAY),'A full day of talks, workshops and networking with East Africa''s developers, founders and investors.'),
(2,'Sunset Jazz Night','Music','Inema Arts Center','Kigali',DATE_ADD(NOW(),INTERVAL 7 DAY),'Live jazz, local food and an open-air stage as the sun goes down.'),
(3,'Startup Pitch Day','Business','University of Rwanda, Huye Campus','Huye',DATE_ADD(NOW(),INTERVAL 21 DAY),'Ten student startups pitch to a panel of investors.'),
(4,'Lake Kivu Marathon','Sports','Gisenyi Beach','Rubavu',DATE_ADD(NOW(),INTERVAL 35 DAY),'Half and full marathon along the shore of Lake Kivu. Medal for every finisher.');
INSERT INTO ticket_types(event_id,name,price,seats,group_size) VALUES
(1,'Regular',15000,150,1),(1,'Silver',25000,80,1),(1,'Gold',60000,20,1),(1,'Platinum Table',250000,10,5),
(2,'Regular',10000,80,1),(2,'Gold Table',80000,10,5),
(3,'Free entry',0,200,1),
(4,'Half marathon',15000,300,1),(4,'Full marathon',25000,200,1);

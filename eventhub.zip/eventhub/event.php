<?php require 'inc.php';require 'mail.php';need_login();
$id=(int)($_GET['id']??0);
$s=$pdo->prepare("SELECT * FROM events WHERE id=? AND status='published'");$s->execute([$id]);$x=$s->fetch();
if(!$x){http_response_code(404);head('Not found');echo '<p>This event does not exist.</p>';foot();exit;}
$past=strtotime($x['event_date'])<time();
$tq="SELECT t.*,".TLEFT." AS left_seats FROM ticket_types t WHERE t.event_id=? ORDER BY t.price,t.id";
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=$pdo->prepare($tq);$s->execute([$id]);$tiers=$s->fetchAll();
 $qty=$_POST['qty']??[];$nm=$_POST['names']??[];$items=[];$err=$past?'This event has already happened.':'';
 foreach($tiers as $t){$q=max(0,(int)($qty[$t['id']]??0));if(!$q||$err)continue;
  if($q>$t['left_seats']){$err="Only {$t['left_seats']} {$t['name']} ".($t['group_size']>1?'table(s)':'seat(s)').' left.';break;}
  for($i=0;$i<$q;$i++){$g=[];for($j=0;$j<$t['group_size'];$j++){$v=trim($nm[$t['id']][$i][$j]??'');if($v===''){$err='Enter the full name of every guest.';break 3;}$g[]=mb_substr($v,0,80);}$items[]=[(int)$t['id'],$g];}}
 if(!$err&&!$items)$err='Choose at least one ticket.';
 if(!$err&&count($items)>10)$err='You can book up to 10 tickets or tables per order.';
 if($err){flash($err,'err');header("Location:event.php?id=$id");exit;}
 $_SESSION['cart']=['event'=>$id,'items'=>$items];header('Location:checkout.php');exit;}
$s=$pdo->prepare($tq);$s->execute([$id]);$tiers=$s->fetchAll();$d=strtotime($x['event_date']);head($x['title']);?>
<div class="detail"><div class="fly"><?=flyer($x)?></div>
<div><span class="tag"><?=e($x['category'])?></span><h1><?=e($x['title'])?></h1>
<p class="muted"><?=date('l, j F Y · H:i',$d)?><br><?=e($x['venue'])?>, <?=e($x['city'])?></p><p class="desc"><?=nl2br(e($x['description']))?></p>
<?php if($past): ?><p class="warn">This event has ended.</p><?php else: ?>
<form method="post" id="f"><h2>Choose your tickets</h2>
<?php foreach($tiers as $t): $l=max(0,$t['left_seats']);$tb=$t['group_size']>1; ?><div class="card tier"><div><h3><?=e($t['name'])?></h3><span class="muted"><?=$tb?'Round table of '.$t['group_size'].' people, price per table':'Numbered seat, price per person'?> · <?=$l?$l.($tb?' table(s)':' seat(s)').' left':'Sold out'?></span></div>
<div class="row"><b><?=money($t['price'])?></b><?php if($l): ?><input type="number" min="0" max="<?=min(10,$l)?>" value="0" name="qty[<?=$t['id']?>]" data-id="<?=$t['id']?>" data-size="<?=$t['group_size']?>" data-name="<?=e($t['name'])?>" data-price="<?=$t['price']?>" aria-label="<?=e($t['name'])?> quantity"><?php endif; ?></div></div><?php endforeach; ?>
<div id="names"></div><p class="muted">Seat or table numbers are assigned when you confirm, and appear on every ticket.</p><p class="row"><b>Total: <span id="sum">Free</span></b><button class="btn">Continue to payment</button></p></form><?php endif; ?></div></div>
<script>const box=document.getElementById('names'),ins=[...document.querySelectorAll('input[data-id]')];
function build(){const v={};box.querySelectorAll('input').forEach(i=>v[i.name]=i.value);let h='',sum=0;
ins.forEach(i=>{const q=+i.value||0,z=+i.dataset.size;sum+=q*i.dataset.price;
for(let t=0;t<q;t++){h+='<fieldset><legend>'+i.dataset.name+(z>1?' table '+(t+1)+' · names of '+z+' guests':' ticket '+(t+1)+' · guest name')+'</legend>';
for(let g=0;g<z;g++)h+='<input required maxlength="80" placeholder="Guest '+(g+1)+' full name" name="names['+i.dataset.id+']['+t+']['+g+']">';h+='</fieldset>';}});
box.innerHTML=h;box.querySelectorAll('input').forEach(i=>{if(v[i.name])i.value=v[i.name]});
document.getElementById('sum').textContent=sum?'RWF '+sum.toLocaleString():'Free';}
ins.forEach(i=>i.addEventListener('input',build));</script>
<?php foot();
